import { useParams } from "react-router-dom"
import userService from "../services/users"
import { useQuery } from "@tanstack/react-query"

const User = () => {
  const id = useParams().id

  const result = useQuery({
    queryKey: ["users"],
    queryFn: userService.getAll,
    refetchOnWindowFocus: false,
    retry: 2,
  })

  if (result.isLoading || result.isError) {
    return (
      <div>Loading...</div>
    )
  }

  const user = result.data.find(u => u.id === id)

  return (
    <div>
      <h2>{user.name}</h2>

      <h4>added blogs:</h4>

      <ul>
        {user.blogs.map(blog => (
          <li key={blog.id}>{blog.title}</li>
        ))}
      </ul>
    </div>
  )
}

export default User