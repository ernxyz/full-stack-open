import { useMutation, useQueryClient } from "@tanstack/react-query"
import { useState } from "react"
import blogService from "../services/blogs"

import { showNotification, useNotificationDispatch } from "./NotificationContextProvider"

const CommentForm = ({ blog }) => {
  const [content, setContent] = useState("")

  const queryClient = useQueryClient()
  const dispatchNotification = useNotificationDispatch()

  const addCommentMutation = useMutation({
    mutationFn: blogService.addComment,
    onSuccess: (commentAdded) => {
      queryClient.invalidateQueries(["blogs"])

      const notificationObj = {
        message: "comment added",
        color: "lightgreen",
      };
      showNotification(dispatchNotification, notificationObj);
    }
  })

  const handleSubmit = (e) => {
    e.preventDefault()

    const blogAndContent = {
      blog,
      content,
    }

    addCommentMutation.mutate(blogAndContent)

    setContent("")
  }

  return (
    <form onSubmit={handleSubmit}>
      <label>
        your comment:
        <input
          type="text"
          value={content}
          onChange={({ target }) => setContent(target.value)}
        />
      </label>
      <button type="submit">add comment</button>
    </form>
  )
}

export default CommentForm