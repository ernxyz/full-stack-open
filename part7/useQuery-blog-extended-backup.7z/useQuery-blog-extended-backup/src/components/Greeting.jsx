import {
  useLoginDispatch,
  useLoginValue,
  logOut,
} from "./LoginContextProvider";
import { showNotification, useNotificationDispatch } from "./NotificationContextProvider";

const Greeting = () => {
  const loginDispatch = useLoginDispatch();
  const dispacthNotification = useNotificationDispatch()

  const user = useLoginValue();

  const logout = () => {
    logOut(loginDispatch);

    const notificationObj = {
      message: "Bye",
      color: "purple",
    }

    showNotification(dispacthNotification, notificationObj)
  };

  if (!user) {
    return;
  }

  return (
    <p style={{ display: "inline-block" }}>
      Hey welcome, {user.name} <button onClick={logout}>Logout</button>
    </p>
  );
};

export default Greeting;
