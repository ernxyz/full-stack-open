import { useState } from "react";

import {
  showNotification,
  useNotificationDispatch,
} from "./NotificationContextProvider";
import { useLoginDispatch, logIn } from "./LoginContextProvider";

const LoginForm = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const loginDispatch = useLoginDispatch();
  const dispatchNotification = useNotificationDispatch();

  const handleSubmit = async (event) => {
    event.preventDefault();

    const userCredentials = {
      username,
      password,
    };

    const notificationObj = {
      message: `Hi ${username}`,
      color: "purple",
    };

    const result = await logIn(loginDispatch, userCredentials)

    if (result === true ) {
      showNotification(dispatchNotification, notificationObj);
    } else {
      showNotification(dispatchNotification, { message: result, color: "red" });
    }

    setUsername("");
    setPassword("");
  };

  return (
    <>
      <h2>Log in</h2>
      <form onSubmit={handleSubmit}>
        <fieldset style={styles.fieldset}>
          <label htmlFor="username">Username</label>
          <input
            id="username"
            type="text"
            value={username}
            onChange={({ target }) => setUsername(target.value)}
            data-testid="username"
          />
          <br />
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={({ target }) => setPassword(target.value)}
            data-testid="password"
          />
          <br />
          <button type="submit">Log in</button>
        </fieldset>
      </form>
    </>
  );
};

const styles = {
  fieldset: {
    display: "flex",
    flexDirection: "column",
    width: "300px",
  },
};

export default LoginForm;
