import { useState } from "react";
import PropTypes from "prop-types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import blogService from "../services/blogs";
import {
  useNotificationDispatch,
  showNotification,
} from "./NotificationContextProvider";
import { useLoginValue } from "./LoginContextProvider";
import { useParams, Link, useNavigate, useMatch } from "react-router-dom";
import CommentForm from "./CommentForm";

const Blog = ({ blog, detailsTest }) => {
  const user = useLoginValue();

  // NEW POINT

  const id = useParams().id
  const navigate = useNavigate()

  const [details, setDetails] = useState("Details");

  const dispatchNotification = useNotificationDispatch();
  const queryClient = useQueryClient()

  const likeBlogMutation = useMutation({
    mutationFn: blogService.updateBlog,
    onSuccess: (updatedBlog) => {
      const blogs = queryClient.getQueryData(["blogs"]);

      const updatedBlogs = blogs.map((blog) =>
        blog.id === updatedBlog.id ? updatedBlog : blog,
      );

      queryClient.setQueryData(["blogs"], updatedBlogs);

      const notificationObj = {
        message: `Like added to "${updatedBlog.title}"`,
        color: "lightgreen",
      };
      showNotification(dispatchNotification, notificationObj);
    },
  });

  const deleteBlogMutation = useMutation({
    mutationFn: blogService.deleteBlog,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["blogs"] });

      const notificationObj = {
        message: "Deleted successfully",
        color: "red",
      };
      showNotification(dispatchNotification, notificationObj);
    },
  });

  const handleLike = (blog) => {
    const updatedBlog = {
      id: blog.id,
      title: blog.title,
      url: blog.url,
      likes: blog.likes + 1,
    };

    likeBlogMutation.mutate(updatedBlog);
  };

  const handleDelete = (blog) => {
    const message = `Do you want to delete "${blog.title}" by ${blog.author.name}`;

    if (window.confirm(message)) {
      deleteBlogMutation.mutate(blog.id);
      navigate("/")
    }
  };

  const blogStyles = {
    container: {
      border: "1px solid black",
      margin: "15px 0",
      width: "500px",
    },
    url: {
      color: "#999",
      margin: 0,
      padding: 0,
    },
    show: {
      display: "",
    },
    hide: {
      display: "none",
    },
  };

  const matchToShowDetails = useMatch("/blogs/:id")

  const result = useQuery({
    queryKey: ["blogs"],
    queryFn: blogService.getAll,
    refetchOnWindowFocus: false,
    retry: 2,
  })

  if (result.isError || result.isLoading) {
    return <div>Loading...</div>
  }

  blog = result.data.find(b => b.id === id) || blog

  return (
    <div style={blogStyles.container} className="blog">
      <h3 style={blogStyles.title}>
        <Link to={`/blogs/${blog.id}`}>{blog.title}</Link> {!matchToShowDetails && <span>| Likes: {blog.likes}</span>}
      </h3>

      <div
        style={matchToShowDetails ? blogStyles.show : blogStyles.hide}
        className="hidenContent"
      >
        <p>
          <a style={blogStyles.url} href={blog.url} target="blank">
            {blog.url}
          </a>
        </p>
        <p>{blog.author.name}</p>
        <p>
          Likes: {blog.likes}{" "}
          {user && (
            <button onClick={() => handleLike(blog)}>👍</button>
          )}
        </p>
        <p>
          {user && user.username === blog.author.username && (
            <button onClick={() => handleDelete(blog)}>🗑️</button>
          )}
        </p>
        {user && (
          <>
            <h3>add comment:</h3>
            <CommentForm blog={blog}/>
          </>
        )}
        <h3>comments:</h3>
        <ul>
          {blog.comments && blog.comments.map(comment => (
            <li key={comment.id}>{comment.content}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

Blog.propTypes = {
  blog: PropTypes.object.isRequired,
};

export default Blog;
