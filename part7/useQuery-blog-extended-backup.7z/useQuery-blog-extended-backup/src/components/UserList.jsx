import { useQuery } from "@tanstack/react-query"
import userService from "../services/users"
import { Link } from "react-router-dom"

const UserList = () => {

  const result = useQuery({
    queryKey: ["users"],
    queryFn: userService.getAll,
    refetchOnWindowFocus: false,
    retry: 2,
  })

  if (result.isLoading || result.isError) {
    return (
      <div>No users to show yet...</div>
    )
  }

  const users = result.data

  // console.log(users)

  const styles = {
    tableStyle: {
      "textAlign": "center",
      "border": "1px solid black",
      "borderSpacing": "15px",
    },
    cellStyle: {
      "padding": "10px",
    }
  }

  return (
    <>
      <h2>users</h2>
      <table style={styles.tableStyle}>
        <thead>
          <tr>
            <th></th>
            <th>blogs created</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user.id}>
              <td><Link to={`/users/${user.id}`}>{user.name}</Link></td>
              <td>{user.blogs.length}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  )
}

export default UserList